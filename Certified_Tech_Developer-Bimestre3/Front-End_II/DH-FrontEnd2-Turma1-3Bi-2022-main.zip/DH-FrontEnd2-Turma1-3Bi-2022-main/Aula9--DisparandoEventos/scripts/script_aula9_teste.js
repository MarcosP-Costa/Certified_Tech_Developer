//Chamando/Invocando uma função que está em outro script
exibeNome("Usuário");