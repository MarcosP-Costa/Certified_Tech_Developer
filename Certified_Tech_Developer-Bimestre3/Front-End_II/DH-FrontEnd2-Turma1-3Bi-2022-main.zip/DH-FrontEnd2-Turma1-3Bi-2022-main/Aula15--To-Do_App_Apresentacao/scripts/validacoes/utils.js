

function normalizaTextoRetiraEspacos (textoRecebido) {
    return textoRecebido.trim();
}